import { Component, Inject } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { NoteStore } from '../../store/note.store';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrl: './note.component.css',
  standalone: true,
  imports: [MatFormFieldModule, MatIconModule, MatButtonModule, CommonModule, ReactiveFormsModule, FormsModule, MatInputModule,],
})
export class NoteComponent {
  selectedIcon: string = '';
  text: string = '';
  isfocused: boolean = false;
  task_list = []
  username: string = 'John Doe';
  noteStore = Inject(NoteStore);

  constructor() {
    this.noteStore.note()
    console.log('this.noteStore.note(): ', this.noteStore.note());
  }


  changeIconColor(event: string) {
    console.log('event: ', event);
    this.selectedIcon = event;
  }

  onFocus() {
    this.isfocused = true;
  }

  onBlur() {
    this.isfocused = false;
  }

  submitTask() {
    if (!this.text || !this.selectedIcon) return;
    const curernt_date = new Date();
    const task = {
      note_type: this.selectedIcon,
      note_text: this.text,
      note_time: curernt_date,
      note_username: this.username
    }
    this.noteStore.addNote(task);
  }

}
