import {
  deepComputed,
  getState,
  patchState,
  signalState,
  signalStore,
  signalStoreFeature,
  type,
  watchState,
  withComputed,
  withHooks,
  withMethods,
  withState
} from "./chunk-C3IGJRG4.js";
import "./chunk-5Z535MOR.js";
export {
  deepComputed,
  getState,
  patchState,
  signalState,
  signalStore,
  signalStoreFeature,
  type,
  watchState,
  withComputed,
  withHooks,
  withMethods,
  withState
};
//# sourceMappingURL=@ngrx_signals.js.map
