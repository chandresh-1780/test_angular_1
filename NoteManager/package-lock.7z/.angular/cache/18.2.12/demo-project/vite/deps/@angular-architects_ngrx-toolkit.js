import {
  getState,
  patchState,
  signalStoreFeature,
  withComputed,
  withHooks,
  withMethods,
  withState
} from "./chunk-C3IGJRG4.js";
import {
  isPlatformServer
} from "./chunk-XRHWA5U6.js";
import {
  PLATFORM_ID,
  Subject,
  __async,
  __spreadProps,
  __spreadValues,
  computed,
  effect,
  inject,
  isSignal,
  signal,
  untracked
} from "./chunk-5Z535MOR.js";

// node_modules/@ngrx/signals/fesm2022/ngrx-signals-entities.mjs
var DidMutate;
(function(DidMutate2) {
  DidMutate2[DidMutate2["None"] = 0] = "None";
  DidMutate2[DidMutate2["Entities"] = 1] = "Entities";
  DidMutate2[DidMutate2["Both"] = 2] = "Both";
})(DidMutate || (DidMutate = {}));
var defaultSelectId = (entity) => entity.id;
function getEntityIdSelector(config) {
  return config?.selectId ?? defaultSelectId;
}
function getEntityStateKeys(config) {
  const collection = config?.collection;
  const entityMapKey = collection === void 0 ? "entityMap" : `${collection}EntityMap`;
  const idsKey = collection === void 0 ? "ids" : `${collection}Ids`;
  const entitiesKey = collection === void 0 ? "entities" : `${collection}Entities`;
  return {
    entityMapKey,
    idsKey,
    entitiesKey
  };
}
function cloneEntityState(state, stateKeys) {
  return {
    entityMap: __spreadValues({}, state[stateKeys.entityMapKey]),
    ids: [...state[stateKeys.idsKey]]
  };
}
function getEntityUpdaterResult(state, stateKeys, didMutate) {
  switch (didMutate) {
    case DidMutate.Both: {
      return {
        [stateKeys.entityMapKey]: state.entityMap,
        [stateKeys.idsKey]: state.ids
      };
    }
    case DidMutate.Entities: {
      return {
        [stateKeys.entityMapKey]: state.entityMap
      };
    }
    default: {
      return {};
    }
  }
}
function addEntityMutably(state, entity, selectId) {
  const id = selectId(entity);
  if (state.entityMap[id]) {
    return DidMutate.None;
  }
  state.entityMap[id] = entity;
  state.ids.push(id);
  return DidMutate.Both;
}
function setEntityMutably(state, entity, selectId) {
  const id = selectId(entity);
  if (state.entityMap[id]) {
    state.entityMap[id] = entity;
    return DidMutate.Entities;
  }
  state.entityMap[id] = entity;
  state.ids.push(id);
  return DidMutate.Both;
}
function setEntitiesMutably(state, entities, selectId) {
  let didMutate = DidMutate.None;
  for (const entity of entities) {
    const result = setEntityMutably(state, entity, selectId);
    if (didMutate === DidMutate.Both) {
      continue;
    }
    didMutate = result;
  }
  return didMutate;
}
function removeEntitiesMutably(state, idsOrPredicate) {
  const ids = Array.isArray(idsOrPredicate) ? idsOrPredicate : state.ids.filter((id) => idsOrPredicate(state.entityMap[id]));
  let didMutate = DidMutate.None;
  for (const id of ids) {
    if (state.entityMap[id]) {
      delete state.entityMap[id];
      didMutate = DidMutate.Both;
    }
  }
  if (didMutate === DidMutate.Both) {
    state.ids = state.ids.filter((id) => id in state.entityMap);
  }
  return didMutate;
}
function updateEntitiesMutably(state, idsOrPredicate, changes, selectId) {
  const ids = Array.isArray(idsOrPredicate) ? idsOrPredicate : state.ids.filter((id) => idsOrPredicate(state.entityMap[id]));
  let newIds = void 0;
  let didMutate = DidMutate.None;
  for (const id of ids) {
    const entity = state.entityMap[id];
    if (entity) {
      const changesRecord = typeof changes === "function" ? changes(entity) : changes;
      state.entityMap[id] = __spreadValues(__spreadValues({}, entity), changesRecord);
      didMutate = DidMutate.Entities;
      const newId = selectId(state.entityMap[id]);
      if (newId !== id) {
        state.entityMap[newId] = state.entityMap[id];
        delete state.entityMap[id];
        newIds = newIds || {};
        newIds[id] = newId;
      }
    }
  }
  if (newIds) {
    state.ids = state.ids.map((id) => newIds[id] ?? id);
    didMutate = DidMutate.Both;
  }
  if (ngDevMode && state.ids.length !== Object.keys(state.entityMap).length) {
    console.warn("@ngrx/signals/entities: Entities with IDs:", ids, "are not updated correctly.", "Make sure to apply valid changes when using `updateEntity`,", "`updateEntities`, and `updateAllEntities` updaters.");
  }
  return didMutate;
}
function addEntity(entity, config) {
  const selectId = getEntityIdSelector(config);
  const stateKeys = getEntityStateKeys(config);
  return (state) => {
    const clonedState = cloneEntityState(state, stateKeys);
    const didMutate = addEntityMutably(clonedState, entity, selectId);
    return getEntityUpdaterResult(clonedState, stateKeys, didMutate);
  };
}
function removeEntity(id, config) {
  const stateKeys = getEntityStateKeys(config);
  return (state) => {
    const clonedState = cloneEntityState(state, stateKeys);
    const didMutate = removeEntitiesMutably(clonedState, [id]);
    return getEntityUpdaterResult(clonedState, stateKeys, didMutate);
  };
}
function setAllEntities(entities, config) {
  const selectId = getEntityIdSelector(config);
  const stateKeys = getEntityStateKeys(config);
  return () => {
    const state = {
      entityMap: {},
      ids: []
    };
    setEntitiesMutably(state, entities, selectId);
    return {
      [stateKeys.entityMapKey]: state.entityMap,
      [stateKeys.idsKey]: state.ids
    };
  };
}
function updateEntity(update, config) {
  const selectId = getEntityIdSelector(config);
  const stateKeys = getEntityStateKeys(config);
  return (state) => {
    const clonedState = cloneEntityState(state, stateKeys);
    const didMutate = updateEntitiesMutably(clonedState, [update.id], update.changes, selectId);
    return getEntityUpdaterResult(clonedState, stateKeys, didMutate);
  };
}

// node_modules/@angular-architects/ngrx-toolkit/fesm2022/angular-architects-ngrx-toolkit.mjs
var storeRegistry = signal({});
var currentActionNames = /* @__PURE__ */ new Set();
var synchronizationInitialized = false;
function initSynchronization() {
  effect(() => {
    if (!connection) {
      return;
    }
    const stores = storeRegistry();
    const rootState = {};
    for (const name in stores) {
      const store = stores[name];
      rootState[name] = store();
    }
    const names = Array.from(currentActionNames);
    const type = names.length ? names.join(", ") : "Store Update";
    currentActionNames = /* @__PURE__ */ new Set();
    connection.send({
      type
    }, rootState);
  });
}
function getValueFromSymbol(obj, symbol) {
  if (typeof obj === "object" && obj && symbol in obj) {
    return obj[symbol];
  }
}
function getStoreSignal(store) {
  const [signalStateKey] = Object.getOwnPropertySymbols(store);
  if (!signalStateKey) {
    throw new Error("Cannot find State Signal");
  }
  return getValueFromSymbol(store, signalStateKey);
}
var connection;
function withDevtools(name) {
  return (store) => {
    const isServer = isPlatformServer(inject(PLATFORM_ID));
    if (isServer) {
      return store;
    }
    const extensions = window.__REDUX_DEVTOOLS_EXTENSION__;
    if (!extensions) {
      return store;
    }
    if (!connection) {
      connection = extensions.connect({
        name: "NgRx Signal Store"
      });
    }
    const storeSignal = getStoreSignal(store);
    storeRegistry.update((value) => __spreadProps(__spreadValues({}, value), {
      [name]: storeSignal
    }));
    if (!synchronizationInitialized) {
      initSynchronization();
      synchronizationInitialized = true;
    }
    return store;
  };
}
var patchState2 = (state, action, ...rest) => {
  updateState(state, action, ...rest);
};
function updateState(stateSource, action, ...updaters) {
  currentActionNames.add(action);
  return patchState(stateSource, ...updaters);
}
function assertActionFnSpecs(obj) {
  if (!obj || typeof obj !== "object") {
    throw new Error("%o is not an Action Specification");
  }
}
function payload() {
  return {};
}
var noPayload = {};
function createActionFns(actionFnSpecs, reducerRegistry, effectsRegistry, state) {
  const actionFns = {};
  for (const type in actionFnSpecs) {
    const actionFn = (payload2) => {
      const fullPayload = __spreadProps(__spreadValues({}, payload2), {
        type
      });
      const reducer = reducerRegistry[type];
      if (reducer) {
        reducer(state, fullPayload);
      }
      const effectSubjects = effectsRegistry[type];
      if (effectSubjects?.length) {
        for (const effectSubject of effectSubjects) {
          effectSubject.next(fullPayload);
        }
      }
      return fullPayload;
    };
    actionFn.type = type.toString();
    actionFns[type] = actionFn;
  }
  return actionFns;
}
function createPublicAndAllActionsFns(actionFnSpecs, reducerRegistry, effectsRegistry, state) {
  if ("public" in actionFnSpecs || "private" in actionFnSpecs) {
    const privates = actionFnSpecs["private"] || {};
    const publics = actionFnSpecs["public"] || {};
    assertActionFnSpecs(privates);
    assertActionFnSpecs(publics);
    const privateActionFns = createActionFns(privates, reducerRegistry, effectsRegistry, state);
    const publicActionFns = createActionFns(publics, reducerRegistry, effectsRegistry, state);
    return {
      all: __spreadValues(__spreadValues({}, privateActionFns), publicActionFns),
      publics: publicActionFns
    };
  }
  const actionFns = createActionFns(actionFnSpecs, reducerRegistry, effectsRegistry, state);
  return {
    all: actionFns,
    publics: actionFns
  };
}
function fillReducerRegistry(reducer, actionFns, reducerRegistry) {
  function on(action, reducerFn) {
    reducerRegistry[action.type] = reducerFn;
  }
  reducer(actionFns, on);
  return reducerRegistry;
}
function fillEffects(effects, actionFns, effectsRegistry = {}) {
  function create(action) {
    const subject = new Subject();
    if (!(action.type in effectsRegistry)) {
      effectsRegistry[action.type] = [];
    }
    effectsRegistry[action.type].push(subject);
    return subject.asObservable();
  }
  const effectObservables = effects(actionFns, create);
  return Object.values(effectObservables);
}
function startSubscriptions(observables) {
  return observables.map((observable) => observable.subscribe());
}
function processRedux(actionFnSpecs, reducer, effects, store) {
  const reducerRegistry = {};
  const effectsRegistry = {};
  const actionsMap = createPublicAndAllActionsFns(actionFnSpecs, reducerRegistry, effectsRegistry, store);
  const actionFns = actionsMap.all;
  const publicActionsFns = actionsMap.publics;
  fillReducerRegistry(reducer, actionFns, reducerRegistry);
  const effectObservables = fillEffects(effects, actionFns, effectsRegistry);
  const subscriptions = startSubscriptions(effectObservables);
  return {
    methods: publicActionsFns,
    subscriptions
  };
}
function withRedux(redux) {
  return (store) => {
    const {
      methods
    } = processRedux(redux.actions, redux.reducer, redux.effects, store);
    return __spreadProps(__spreadValues({}, store), {
      methods
    });
  };
}
function getCallStateKeys(config) {
  const prop = config?.collection;
  return {
    callStateKey: prop ? `${config.collection}CallState` : "callState",
    loadingKey: prop ? `${config.collection}Loading` : "loading",
    loadedKey: prop ? `${config.collection}Loaded` : "loaded",
    errorKey: prop ? `${config.collection}Error` : "error"
  };
}
function withCallState(config) {
  const {
    callStateKey,
    errorKey,
    loadedKey,
    loadingKey
  } = getCallStateKeys(config);
  return signalStoreFeature(withState({
    [callStateKey]: "init"
  }), withComputed((state) => {
    const callState = state[callStateKey];
    return {
      [loadingKey]: computed(() => callState() === "loading"),
      [loadedKey]: computed(() => callState() === "loaded"),
      [errorKey]: computed(() => {
        const v = callState();
        return typeof v === "object" ? v.error : null;
      })
    };
  }));
}
function setLoading(prop) {
  if (prop) {
    return {
      [`${prop}CallState`]: "loading"
    };
  }
  return {
    callState: "loading"
  };
}
function setLoaded(prop) {
  if (prop) {
    return {
      [`${prop}CallState`]: "loaded"
    };
  } else {
    return {
      callState: "loaded"
    };
  }
}
function setError(error, prop) {
  let errorMessage;
  if (!error) {
    errorMessage = "";
  } else if (typeof error === "object" && "message" in error) {
    errorMessage = String(error.message);
  } else {
    errorMessage = String(error);
  }
  if (prop) {
    return {
      [`${prop}CallState`]: {
        error: errorMessage
      }
    };
  } else {
    return {
      callState: {
        error: errorMessage
      }
    };
  }
}
function capitalize(str) {
  return str ? str[0].toUpperCase() + str.substring(1) : str;
}
function getDataServiceKeys(options) {
  const filterKey = options.collection ? `${options.collection}Filter` : "filter";
  const selectedIdsKey = options.collection ? `selected${capitalize(options.collection)}Ids` : "selectedIds";
  const selectedEntitiesKey = options.collection ? `selected${capitalize(options.collection)}Entities` : "selectedEntities";
  const updateFilterKey = options.collection ? `update${capitalize(options.collection)}Filter` : "updateFilter";
  const updateSelectedKey = options.collection ? `updateSelected${capitalize(options.collection)}Entities` : "updateSelected";
  const loadKey = options.collection ? `load${capitalize(options.collection)}Entities` : "load";
  const currentKey = options.collection ? `current${capitalize(options.collection)}` : "current";
  const loadByIdKey = options.collection ? `load${capitalize(options.collection)}ById` : "loadById";
  const setCurrentKey = options.collection ? `setCurrent${capitalize(options.collection)}` : "setCurrent";
  const createKey = options.collection ? `create${capitalize(options.collection)}` : "create";
  const updateKey = options.collection ? `update${capitalize(options.collection)}` : "update";
  const updateAllKey = options.collection ? `updateAll${capitalize(options.collection)}` : "updateAll";
  const deleteKey = options.collection ? `delete${capitalize(options.collection)}` : "delete";
  const entitiesKey = options.collection ? `${options.collection}Entities` : "entities";
  const entityMapKey = options.collection ? `${options.collection}EntityMap` : "entityMap";
  const idsKey = options.collection ? `${options.collection}Ids` : "ids";
  return {
    filterKey,
    selectedIdsKey,
    selectedEntitiesKey,
    updateFilterKey,
    updateSelectedKey,
    loadKey,
    entitiesKey,
    entityMapKey,
    idsKey,
    currentKey,
    loadByIdKey,
    setCurrentKey,
    createKey,
    updateKey,
    updateAllKey,
    deleteKey
  };
}
function withDataService(options) {
  const {
    dataServiceType,
    filter,
    collection: prefix
  } = options;
  const {
    entitiesKey,
    filterKey,
    loadKey,
    selectedEntitiesKey,
    selectedIdsKey,
    updateFilterKey,
    updateSelectedKey,
    currentKey,
    createKey,
    updateKey,
    updateAllKey,
    deleteKey,
    loadByIdKey,
    setCurrentKey
  } = getDataServiceKeys(options);
  const {
    callStateKey
  } = getCallStateKeys({
    collection: prefix
  });
  return signalStoreFeature(withState(() => ({
    [filterKey]: filter,
    [selectedIdsKey]: {},
    [currentKey]: void 0
  })), withComputed((store) => {
    const entities = store[entitiesKey];
    const selectedIds = store[selectedIdsKey];
    return {
      [selectedEntitiesKey]: computed(() => entities().filter((e) => selectedIds()[e.id]))
    };
  }), withMethods((store) => {
    const dataService = inject(dataServiceType);
    return {
      [updateFilterKey]: (filter2) => {
        patchState(store, {
          [filterKey]: filter2
        });
      },
      [updateSelectedKey]: (id, selected) => {
        patchState(store, (state) => ({
          [selectedIdsKey]: __spreadProps(__spreadValues({}, state[selectedIdsKey]), {
            [id]: selected
          })
        }));
      },
      [loadKey]: () => __async(this, null, function* () {
        const filter2 = store[filterKey];
        store[callStateKey] && patchState(store, setLoading(prefix));
        try {
          const result = yield dataService.load(filter2());
          patchState(store, prefix ? setAllEntities(result, {
            collection: prefix
          }) : setAllEntities(result));
          store[callStateKey] && patchState(store, setLoaded(prefix));
        } catch (e) {
          store[callStateKey] && patchState(store, setError(e, prefix));
          throw e;
        }
      }),
      [loadByIdKey]: (id) => __async(this, null, function* () {
        store[callStateKey] && patchState(store, setLoading(prefix));
        try {
          const current = yield dataService.loadById(id);
          store[callStateKey] && patchState(store, setLoaded(prefix));
          patchState(store, {
            [currentKey]: current
          });
        } catch (e) {
          store[callStateKey] && patchState(store, setError(e, prefix));
          throw e;
        }
      }),
      [setCurrentKey]: (current) => {
        patchState(store, {
          [currentKey]: current
        });
      },
      [createKey]: (entity) => __async(this, null, function* () {
        patchState(store, {
          [currentKey]: entity
        });
        store[callStateKey] && patchState(store, setLoading(prefix));
        try {
          const created = yield dataService.create(entity);
          patchState(store, {
            [currentKey]: created
          });
          patchState(store, prefix ? addEntity(created, {
            collection: prefix
          }) : addEntity(created));
          store[callStateKey] && patchState(store, setLoaded(prefix));
        } catch (e) {
          store[callStateKey] && patchState(store, setError(e, prefix));
          throw e;
        }
      }),
      [updateKey]: (entity) => __async(this, null, function* () {
        patchState(store, {
          [currentKey]: entity
        });
        store[callStateKey] && patchState(store, setLoading(prefix));
        try {
          const updated = yield dataService.update(entity);
          patchState(store, {
            [currentKey]: updated
          });
          const updateArg = {
            id: updated.id,
            changes: updated
          };
          const updater = (collection) => updateEntity(updateArg, {
            collection
          });
          patchState(store, prefix ? updater(prefix) : updateEntity(updateArg));
          store[callStateKey] && patchState(store, setLoaded(prefix));
        } catch (e) {
          store[callStateKey] && patchState(store, setError(e, prefix));
          throw e;
        }
      }),
      [updateAllKey]: (entities) => __async(this, null, function* () {
        store[callStateKey] && patchState(store, setLoading(prefix));
        try {
          const result = yield dataService.updateAll(entities);
          patchState(store, prefix ? setAllEntities(result, {
            collection: prefix
          }) : setAllEntities(result));
          store[callStateKey] && patchState(store, setLoaded(prefix));
        } catch (e) {
          store[callStateKey] && patchState(store, setError(e, prefix));
          throw e;
        }
      }),
      [deleteKey]: (entity) => __async(this, null, function* () {
        patchState(store, {
          [currentKey]: entity
        });
        store[callStateKey] && patchState(store, setLoading(prefix));
        try {
          yield dataService.delete(entity);
          patchState(store, {
            [currentKey]: void 0
          });
          patchState(store, prefix ? removeEntity(entity.id, {
            collection: prefix
          }) : removeEntity(entity.id));
          store[callStateKey] && patchState(store, setLoaded(prefix));
        } catch (e) {
          store[callStateKey] && patchState(store, setError(e, prefix));
          throw e;
        }
      })
    };
  }));
}
var defaultOptions = {
  maxStackSize: 100,
  keys: [],
  skip: 0
};
function getUndoRedoKeys(collections) {
  if (collections) {
    return collections.flatMap((c) => [`${c}EntityMap`, `${c}Ids`, `selected${capitalize(c)}Ids`, `${c}Filter`]);
  }
  return ["entityMap", "ids", "selectedIds", "filter"];
}
function withUndoRedo(options) {
  let previous = null;
  let skipOnce = false;
  const normalized = __spreadValues(__spreadValues({}, defaultOptions), options);
  const undoStack = [];
  const redoStack = [];
  const canUndo = signal(false);
  const canRedo = signal(false);
  const updateInternal = () => {
    canUndo.set(undoStack.length !== 0);
    canRedo.set(redoStack.length !== 0);
  };
  const keys = [...getUndoRedoKeys(normalized.collections), ...normalized.keys];
  return signalStoreFeature(withComputed(() => ({
    canUndo: canUndo.asReadonly(),
    canRedo: canRedo.asReadonly()
  })), withMethods((store) => ({
    undo() {
      const item = undoStack.pop();
      if (item && previous) {
        redoStack.push(previous);
      }
      if (item) {
        skipOnce = true;
        patchState(store, item);
        previous = item;
      }
      updateInternal();
    },
    redo() {
      const item = redoStack.pop();
      if (item && previous) {
        undoStack.push(previous);
      }
      if (item) {
        skipOnce = true;
        patchState(store, item);
        previous = item;
      }
      updateInternal();
    }
  })), withHooks({
    onInit(store) {
      effect(() => {
        const cand = keys.reduce((acc, key) => {
          const s = store[key];
          if (s && isSignal(s)) {
            return __spreadProps(__spreadValues({}, acc), {
              [key]: s()
            });
          }
          return acc;
        }, {});
        if (normalized.skip > 0) {
          normalized.skip--;
          return;
        }
        if (skipOnce) {
          skipOnce = false;
          return;
        }
        if (JSON.stringify(cand) === JSON.stringify(previous)) {
          return;
        }
        redoStack.splice(0);
        if (previous) {
          undoStack.push(previous);
        }
        if (redoStack.length > normalized.maxStackSize) {
          undoStack.unshift();
        }
        previous = cand;
        untracked(() => updateInternal());
      });
    }
  }));
}
var NOOP = () => {
};
var StorageSyncStub = {
  clearStorage: NOOP,
  readFromStorage: NOOP,
  writeToStorage: NOOP
};
function withStorageSync(configOrKey) {
  const {
    key,
    autoSync = true,
    select = (state) => state,
    parse = JSON.parse,
    stringify = JSON.stringify,
    storage: storageFactory = () => localStorage
  } = typeof configOrKey === "string" ? {
    key: configOrKey
  } : configOrKey;
  return signalStoreFeature(withMethods((store, platformId = inject(PLATFORM_ID)) => {
    if (isPlatformServer(platformId)) {
      console.warn(`'withStorageSync' provides non-functional implementation due to server-side execution`);
      return StorageSyncStub;
    }
    const storage = storageFactory();
    return {
      /**
       * Removes the item stored in storage.
       */
      clearStorage() {
        storage.removeItem(key);
      },
      /**
       * Reads item from storage and patches the state.
       */
      readFromStorage() {
        const stateString = storage.getItem(key);
        if (stateString) {
          patchState(store, parse(stateString));
        }
      },
      /**
       * Writes selected portion to storage.
       */
      writeToStorage() {
        const slicedState = select(getState(store));
        storage.setItem(key, stringify(slicedState));
      }
    };
  }), withHooks({
    onInit(store, platformId = inject(PLATFORM_ID)) {
      if (isPlatformServer(platformId)) {
        return;
      }
      if (autoSync) {
        store.readFromStorage();
        effect(() => {
          store.writeToStorage();
        });
      }
    }
  }));
}
function withPagination(options) {
  const {
    pageKey,
    pageSizeKey,
    entitiesKey,
    selectedPageEntitiesKey,
    totalCountKey,
    pageCountKey,
    pageNavigationArrayMaxKey,
    pageNavigationArrayKey,
    setPageSizeKey,
    nextPageKey,
    previousPageKey,
    lastPageKey,
    firstPageKey,
    gotoPageKey,
    hasNextPageKey,
    hasPreviousPageKey
  } = createPaginationKeys(options);
  return signalStoreFeature(withState({
    [pageKey]: 0,
    [pageSizeKey]: 10,
    [pageNavigationArrayMaxKey]: 7
  }), withComputed((store) => {
    const entities = store[entitiesKey];
    const page = store[pageKey];
    const pageSize = store[pageSizeKey];
    const pageNavigationArrayMax = store[pageNavigationArrayMaxKey];
    return {
      // The derived enitites which are displayed on the current page
      [selectedPageEntitiesKey]: computed(() => {
        const pageSizeValue = pageSize();
        const pageValue = page();
        return entities().slice(pageValue * pageSizeValue, (pageValue + 1) * pageSizeValue);
      }),
      [totalCountKey]: computed(() => entities().length),
      [pageCountKey]: computed(() => {
        const totalCountValue = entities().length;
        const pageSizeValue = pageSize();
        if (totalCountValue === 0) {
          return 0;
        }
        return Math.ceil(totalCountValue / pageSizeValue);
      }),
      [pageNavigationArrayKey]: computed(() => createPageArray(page(), pageSize(), entities().length, pageNavigationArrayMax())),
      [hasNextPageKey]: computed(() => {
        return page() < pageSize();
      }),
      [hasPreviousPageKey]: computed(() => {
        return page() > 1;
      })
    };
  }), withMethods((store) => {
    return {
      [setPageSizeKey]: (size) => {
        patchState(store, setPageSize(size, options));
      },
      [nextPageKey]: () => {
        patchState(store, nextPage(options));
      },
      [previousPageKey]: () => {
        patchState(store, previousPage(options));
      },
      [lastPageKey]: () => {
        const lastPage = store[pageCountKey]();
        if (lastPage === 0) return;
        patchState(store, gotoPage(lastPage - 1, options));
      },
      [firstPageKey]: () => {
        patchState(store, firstPage());
      },
      [gotoPageKey]: (page) => {
        patchState(store, gotoPage(page, options));
      }
    };
  }));
}
function gotoPage(page, options) {
  const {
    pageKey
  } = createPaginationKeys(options);
  return {
    [pageKey]: page
  };
}
function setPageSize(pageSize, options) {
  const {
    pageSizeKey
  } = createPaginationKeys(options);
  return {
    [pageSizeKey]: pageSize
  };
}
function nextPage(options) {
  const {
    pageKey
  } = createPaginationKeys(options);
  return {
    [pageKey]: (currentPage) => currentPage + 1
  };
}
function previousPage(options) {
  const {
    pageKey
  } = createPaginationKeys(options);
  return {
    [pageKey]: (currentPage) => Math.max(currentPage - 1, 1)
  };
}
function firstPage(options) {
  const {
    pageKey
  } = createPaginationKeys(options);
  return {
    [pageKey]: 1
  };
}
function setMaxPageNavigationArrayItems(maxPageNavigationArrayItems, options) {
  const {
    pageNavigationArrayMaxKey
  } = createPaginationKeys(options);
  return {
    [pageNavigationArrayMaxKey]: maxPageNavigationArrayItems
  };
}
function createPaginationKeys(options) {
  const entitiesKey = options?.collection ? `${options.collection}Entities` : "entities";
  const selectedPageEntitiesKey = options?.collection ? `selectedPage${capitalize(options?.collection)}Entities` : "selectedPageEntities";
  const pageKey = options?.collection ? `${options.collection}CurrentPage` : "currentPage";
  const pageSizeKey = options?.collection ? `${options.collection}PageSize` : "pageSize";
  const totalCountKey = options?.collection ? `${options.collection}TotalCount` : "totalCount";
  const pageCountKey = options?.collection ? `${options.collection}PageCount` : "pageCount";
  const pageNavigationArrayMaxKey = options?.collection ? `${options.collection}PageNavigationArrayMax` : "pageNavigationArrayMax";
  const pageNavigationArrayKey = options?.collection ? `${options.collection}PageNavigationArray` : "pageNavigationArray";
  const setPageSizeKey = options?.collection ? `set${capitalize(options.collection)}PageSize` : "setPageSize";
  const nextPageKey = options?.collection ? `next${capitalize(options.collection)}Page` : "nextPage";
  const previousPageKey = options?.collection ? `previous${capitalize(options.collection)}Page` : "previousPage";
  const lastPageKey = options?.collection ? `last${capitalize(options.collection)}Page` : "lastPage";
  const firstPageKey = options?.collection ? `first${capitalize(options.collection)}Page` : "firstPage";
  const gotoPageKey = options?.collection ? `goto${capitalize(options.collection)}Page` : "gotoPage";
  const hasNextPageKey = options?.collection ? `hasNext${capitalize(options.collection)}Page` : "hasNextPage";
  const hasPreviousPageKey = options?.collection ? `hasPrevious${capitalize(options.collection)}Page` : "hasPreviousPage";
  return {
    pageKey,
    pageSizeKey,
    entitiesKey,
    selectedPageEntitiesKey,
    totalCountKey,
    pageCountKey,
    pageNavigationArrayKey,
    pageNavigationArrayMaxKey,
    setPageSizeKey,
    nextPageKey,
    previousPageKey,
    lastPageKey,
    firstPageKey,
    gotoPageKey,
    hasNextPageKey,
    hasPreviousPageKey
  };
}
function createPageArray(currentPage, itemsPerPage, totalItems, paginationRange) {
  paginationRange = +paginationRange;
  const totalPages = Math.max(Math.ceil(totalItems / itemsPerPage), 1);
  const halfWay = Math.ceil(paginationRange / 2);
  const isStart = currentPage <= halfWay;
  const isEnd = totalPages - halfWay < currentPage;
  const isMiddle = !isStart && !isEnd;
  const ellipsesNeeded = paginationRange < totalPages;
  const pages = [];
  for (let i = 1; i <= totalPages && i <= paginationRange; i++) {
    let pageNumber = i;
    if (i === paginationRange) {
      pageNumber = totalPages;
    } else if (ellipsesNeeded) {
      if (isEnd) {
        pageNumber = totalPages - paginationRange + i;
      } else if (isMiddle) {
        pageNumber = currentPage - halfWay + i;
      }
    }
    const openingEllipsesNeeded = i === 2 && (isMiddle || isEnd);
    const closingEllipsesNeeded = i === paginationRange - 1 && (isMiddle || isStart);
    const label = ellipsesNeeded && (openingEllipsesNeeded || closingEllipsesNeeded) ? "..." : pageNumber;
    pages.push({
      label,
      value: pageNumber
    });
  }
  return pages;
}
export {
  capitalize,
  createPageArray,
  firstPage,
  getCallStateKeys,
  getDataServiceKeys,
  getUndoRedoKeys,
  gotoPage,
  nextPage,
  noPayload,
  patchState2 as patchState,
  payload,
  previousPage,
  setError,
  setLoaded,
  setLoading,
  setMaxPageNavigationArrayItems,
  setPageSize,
  updateState,
  withCallState,
  withDataService,
  withDevtools,
  withPagination,
  withRedux,
  withStorageSync,
  withUndoRedo
};
//# sourceMappingURL=@angular-architects_ngrx-toolkit.js.map
